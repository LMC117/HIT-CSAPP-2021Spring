#include <stdio.h>
int main(){
	printf("Hello 1190200208李旻翀");
	return 0;
}
